package com.christian.triki;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
